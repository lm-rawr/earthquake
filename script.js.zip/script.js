import * as THREE from 'https://cdn.skypack.dev/three@0.129.0/build/three.module.js';
// import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'https://cdn.skypack.dev/three@0.129.0/examples/jsm/loaders/GLTFLoader.js';
// import { gsap } from 'https://cdn.skypack.dev/gsap'

const camera = new THREE.PerspectiveCamera(
	10,
	window.innerWidth/window.innerHeight,
	0.1,
	1000);

camera.position.z = 13;

let scrollPosY = 0;

const scene = new THREE.Scene();
let bee;
const loader = new GLTFLoader();
loader.load('dharahara.glb',
	function (gltf) {
		bee = gltf.scene;
		bee.position.x = 0;
		bee.position.z = 4;
		bee.position.y = -0.3;
		bee.rotation.y = 0;
		bee.rotation.x = 0.3;
		bee.scale.y = 0.1;
		bee.scale.x = 0.1;
		bee.scale.z = 0.1;

		scene.add(bee);
	},
	function (xhr) {},
	function (err) {}
	);

const renderer = new THREE.WebGLRenderer({alpha: true});
renderer.setSize(window.innerWidth, window.innerHeight);
document.getElementById('container3d').appendChild(renderer.domElement);


const ambientLight = new THREE.AmbientLight(0xffffff, 2);
scene.add(ambientLight);

const topLight = new THREE.DirectionalLight(0xffffff, 2);
topLight.position.set(500, 500, 500);
scene.add(topLight);

const reRender3d = () => {
	requestAnimationFrame(reRender3d);
	renderer.render(scene, camera);
};
reRender3d();


// let arrPositions = [
// 	{
// 		id: 'beginning',
// 		position: {x: 0, y: -0.3, z: 4},
// 		rotation: {x: 0.3, y: 0, z: 0},
// 	},
// 	{
// 		id: 'end',
// 		position: {x:0, y: 0.3, z: 4},
// 		rotation: {x: -0.3, y: 6.28, z: 0},
// 	}
// ];

const modelMove = () => {
	// const sections = document.querySelectorAll('.section');
	// let currentSection;
	// sections.forEach( (section) => {
	// 	const rect = section.getBoundingClientRect();
	// 	if (rect.top <= window.innerHeight/2) {
	// 		currentSection = section.id;
	// 	}
	// });
	// console.log(currentSection);
	// let position_active = arrPositions.findIndex(
	// 	(val) => val.id == currentSection
	// 	);
	// if (position_active >= 0){
	// 	let new_coordinates = arrPositions[position_active];
	// 	gsap.to(bee.position, {
	// 		x: new_coordinates.position.x,
	// 		y: new_coordinates.position.y,
	// 		z: new_coordinates.position.z,

	// 	})
	// 	gsap.to(bee.rotation, {
	// 		x: new_coordinates.rotation.x,
	// 		y: new_coordinates.rotation.y,
	// 		z: new_coordinates.rotation.z,
	// 	})
	// }
	scrollPosY = (window.scrollY/document.body.clientHeight);
	bee.rotation.y = 4 * Math.PI * scrollPosY;
	bee.rotation.x = -0.5* scrollPosY;
	bee.position.y = -1 * scrollPosY;
	bee.position.z =  5 * scrollPosY;
}


window.addEventListener('scroll', () => {
	if (bee){
		modelMove();
	}
})